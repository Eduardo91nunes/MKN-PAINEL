const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + "-" + file.originalname;
    cb(null, uniqueName);
  }
});

const upload = multer({ storage });

app.post("/upload", upload.single("imagem"), (req, res) => {
  const { texto } = req.body;
  const imagemUrl = `http://localhost:3001/uploads/${req.file.filename}`;

  return res.json({
    mensagem: "Postagem recebida com sucesso!",
    dados: {
      texto,
      imagemUrl
    }
  });
});

app.listen(3001, () => {
  console.log("API rodando em http://localhost:3001");
});
